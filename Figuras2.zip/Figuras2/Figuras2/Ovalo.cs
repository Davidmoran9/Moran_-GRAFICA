﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figuras2
{
    public class Ovalo : Elipse
    {
        public Ovalo(double ejeMayor, double ejeMenor) : base(ejeMayor, ejeMenor) { }
    }

}
