﻿namespace Figuras2
{
    partial class Figuras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbFiguras = new ComboBox();
            lblSeleccion = new Label();
            grpParametros = new GroupBox();
            txtParametro8 = new TextBox();
            lblParametro7 = new Label();
            txtParametro6 = new TextBox();
            txtParametro5 = new TextBox();
            txtParametro4 = new TextBox();
            txtParametro3 = new TextBox();
            txtParametro2 = new TextBox();
            txtParametro1 = new TextBox();
            lblParametro6 = new Label();
            lblParametro5 = new Label();
            lblParametro4 = new Label();
            lblParametro3 = new Label();
            lblParametro2 = new Label();
            lblParametro1 = new Label();
            btnCalcular = new Button();
            lblTextoArea = new Label();
            lblResultadoArea = new Label();
            lblTextoPerimetro = new Label();
            lblResultadoPerimetro = new Label();
            IbIParametro8 = new Label();
            grpParametros.SuspendLayout();
            SuspendLayout();
            // 
            // cmbFiguras
            // 
            cmbFiguras.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFiguras.FormattingEnabled = true;
            cmbFiguras.Location = new Point(316, 82);
            cmbFiguras.Name = "cmbFiguras";
            cmbFiguras.Size = new Size(119, 28);
            cmbFiguras.TabIndex = 0;
            cmbFiguras.SelectedIndexChanged += cmbFiguras_SelectedIndexChanged;
            // 
            // lblSeleccion
            // 
            lblSeleccion.AutoSize = true;
            lblSeleccion.Location = new Point(156, 85);
            lblSeleccion.Name = "lblSeleccion";
            lblSeleccion.Size = new Size(154, 20);
            lblSeleccion.TabIndex = 1;
            lblSeleccion.Text = "Seleccione una figura:";
            // 
            // grpParametros
            // 
            grpParametros.BackColor = SystemColors.ButtonFace;
            grpParametros.Controls.Add(IbIParametro8);
            grpParametros.Controls.Add(txtParametro8);
            grpParametros.Controls.Add(lblParametro7);
            grpParametros.Controls.Add(txtParametro6);
            grpParametros.Controls.Add(txtParametro5);
            grpParametros.Controls.Add(txtParametro4);
            grpParametros.Controls.Add(txtParametro3);
            grpParametros.Controls.Add(txtParametro2);
            grpParametros.Controls.Add(txtParametro1);
            grpParametros.Controls.Add(lblParametro6);
            grpParametros.Controls.Add(lblParametro5);
            grpParametros.Controls.Add(lblParametro4);
            grpParametros.Controls.Add(lblParametro3);
            grpParametros.Controls.Add(lblParametro2);
            grpParametros.Controls.Add(lblParametro1);
            grpParametros.Location = new Point(217, 136);
            grpParametros.Name = "grpParametros";
            grpParametros.Size = new Size(326, 274);
            grpParametros.TabIndex = 2;
            grpParametros.TabStop = false;
            grpParametros.Text = "Parámetros";
            // 
            // txtParametro8
            // 
            txtParametro8.Location = new Point(132, 236);
            txtParametro8.Name = "txtParametro8";
            txtParametro8.Size = new Size(125, 27);
            txtParametro8.TabIndex = 13;
            // 
            // lblParametro7
            // 
            lblParametro7.Location = new Point(0, 0);
            lblParametro7.Name = "lblParametro7";
            lblParametro7.Size = new Size(100, 23);
            lblParametro7.TabIndex = 14;
            // 
            // txtParametro6
            // 
            txtParametro6.Location = new Point(132, 203);
            txtParametro6.Name = "txtParametro6";
            txtParametro6.Size = new Size(125, 27);
            txtParametro6.TabIndex = 11;
            // 
            // txtParametro5
            // 
            txtParametro5.Location = new Point(132, 170);
            txtParametro5.Name = "txtParametro5";
            txtParametro5.Size = new Size(125, 27);
            txtParametro5.TabIndex = 10;
            // 
            // txtParametro4
            // 
            txtParametro4.Location = new Point(132, 137);
            txtParametro4.Name = "txtParametro4";
            txtParametro4.Size = new Size(125, 27);
            txtParametro4.TabIndex = 9;
            // 
            // txtParametro3
            // 
            txtParametro3.Location = new Point(132, 104);
            txtParametro3.Name = "txtParametro3";
            txtParametro3.Size = new Size(125, 27);
            txtParametro3.TabIndex = 8;
            // 
            // txtParametro2
            // 
            txtParametro2.Location = new Point(132, 71);
            txtParametro2.Name = "txtParametro2";
            txtParametro2.Size = new Size(125, 27);
            txtParametro2.TabIndex = 7;
            // 
            // txtParametro1
            // 
            txtParametro1.Location = new Point(132, 38);
            txtParametro1.Name = "txtParametro1";
            txtParametro1.Size = new Size(125, 27);
            txtParametro1.TabIndex = 6;
            // 
            // lblParametro6
            // 
            lblParametro6.AutoSize = true;
            lblParametro6.Location = new Point(24, 203);
            lblParametro6.Name = "lblParametro6";
            lblParametro6.Size = new Size(102, 20);
            lblParametro6.TabIndex = 5;
            lblParametro6.Text = "lblParametro6";
            // 
            // lblParametro5
            // 
            lblParametro5.AutoSize = true;
            lblParametro5.Location = new Point(24, 170);
            lblParametro5.Name = "lblParametro5";
            lblParametro5.Size = new Size(102, 20);
            lblParametro5.TabIndex = 4;
            lblParametro5.Text = "lblParametro5";
            // 
            // lblParametro4
            // 
            lblParametro4.AutoSize = true;
            lblParametro4.Location = new Point(24, 137);
            lblParametro4.Name = "lblParametro4";
            lblParametro4.Size = new Size(102, 20);
            lblParametro4.TabIndex = 3;
            lblParametro4.Text = "lblParametro4";
            // 
            // lblParametro3
            // 
            lblParametro3.AutoSize = true;
            lblParametro3.Location = new Point(24, 104);
            lblParametro3.Name = "lblParametro3";
            lblParametro3.Size = new Size(102, 20);
            lblParametro3.TabIndex = 2;
            lblParametro3.Text = "lblParametro3";
            // 
            // lblParametro2
            // 
            lblParametro2.AutoSize = true;
            lblParametro2.Location = new Point(24, 71);
            lblParametro2.Name = "lblParametro2";
            lblParametro2.Size = new Size(102, 20);
            lblParametro2.TabIndex = 1;
            lblParametro2.Text = "lblParametro2";
            // 
            // lblParametro1
            // 
            lblParametro1.AutoSize = true;
            lblParametro1.Location = new Point(24, 38);
            lblParametro1.Name = "lblParametro1";
            lblParametro1.Size = new Size(102, 20);
            lblParametro1.TabIndex = 0;
            lblParametro1.Text = "lblParametro1";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(342, 440);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(94, 29);
            btnCalcular.TabIndex = 3;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblTextoArea
            // 
            lblTextoArea.AutoSize = true;
            lblTextoArea.Location = new Point(157, 474);
            lblTextoArea.Name = "lblTextoArea";
            lblTextoArea.Size = new Size(40, 20);
            lblTextoArea.TabIndex = 4;
            lblTextoArea.Text = "Área";
            // 
            // lblResultadoArea
            // 
            lblResultadoArea.AutoSize = true;
            lblResultadoArea.Location = new Point(159, 498);
            lblResultadoArea.Name = "lblResultadoArea";
            lblResultadoArea.Size = new Size(9, 20);
            lblResultadoArea.TabIndex = 5;
            lblResultadoArea.Text = "\r\n";
            // 
            // lblTextoPerimetro
            // 
            lblTextoPerimetro.AutoSize = true;
            lblTextoPerimetro.Location = new Point(490, 474);
            lblTextoPerimetro.Name = "lblTextoPerimetro";
            lblTextoPerimetro.Size = new Size(76, 20);
            lblTextoPerimetro.TabIndex = 6;
            lblTextoPerimetro.Text = "Perímetro:";
            // 
            // lblResultadoPerimetro
            // 
            lblResultadoPerimetro.AutoSize = true;
            lblResultadoPerimetro.Location = new Point(501, 498);
            lblResultadoPerimetro.Name = "lblResultadoPerimetro";
            lblResultadoPerimetro.Size = new Size(0, 20);
            lblResultadoPerimetro.TabIndex = 7;
            // 
            // IbIParametro8
            // 
            IbIParametro8.AutoSize = true;
            IbIParametro8.Location = new Point(24, 236);
            IbIParametro8.Name = "IbIParametro8";
            IbIParametro8.Size = new Size(102, 20);
            IbIParametro8.TabIndex = 15;
            IbIParametro8.Text = "IbIParametro8";
            // 
            // Figuras
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(800, 559);
            Controls.Add(lblResultadoPerimetro);
            Controls.Add(lblTextoPerimetro);
            Controls.Add(lblResultadoArea);
            Controls.Add(lblTextoArea);
            Controls.Add(btnCalcular);
            Controls.Add(grpParametros);
            Controls.Add(lblSeleccion);
            Controls.Add(cmbFiguras);
            Name = "Figuras";
            Text = "Figuras";
            Load += Figuras_Load;
            grpParametros.ResumeLayout(false);
            grpParametros.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbFiguras;
        private Label lblSeleccion;
        private GroupBox grpParametros;
        private TextBox txtParametro6;
        private TextBox txtParametro5;
        private TextBox txtParametro4;
        private TextBox txtParametro3;
        private TextBox txtParametro2;
        private TextBox txtParametro1;
        private Label lblParametro6;
        private Label lblParametro5;
        private Label lblParametro4;
        private Label lblParametro3;
        private Label lblParametro2;
        private Label lblParametro1;
        private Button btnCalcular;
        private Label lblTextoArea;
        private Label lblResultadoArea;
        private Label lblTextoPerimetro;
        private Label lblResultadoPerimetro;
        private Label lblParametro7;
        private TextBox txtParametro8;
        private Label IbIParametro8;
    }
}